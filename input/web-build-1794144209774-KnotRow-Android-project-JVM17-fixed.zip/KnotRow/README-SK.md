# KnotRow – prvá testovacia verzia

Táto verzia je Android projekt. APK sa zostaví v GitHub Actions, takže nie je potrebný počítač.

## Čo táto verzia vie
- vybrať screenshot BraceletBook z telefónu,
- nastaviť horný a dolný okraj oblasti vzoru,
- zadať počet riadkov,
- zobraziť jeden horizontálny výrez na riadok,
- prechádzať tlačidlami Predošlý / Ďalší,
- zapamätať si obrázok a nastavenia offline.

## Dôležité obmedzenie prototypu
Toto je prvý funkčný prototyp pre testovanie práce s riadkami. Zatiaľ automaticky nerozpoznáva jednotlivé uzly ani neimportuje dáta z BraceletBook. Pracuje s výrezmi pôvodného screenshotu. Pri niektorých vzoroch bude potrebné doladiť začiatok/koniec oblasti a výšku riadka. Import cez URL a skutočné dekódovanie uzlov sú ďalšie fázy.

## Ako získať APK iba cez telefón
1. V mobile otvor GitHub a vytvor nový prázdny repository s názvom `KnotRow`.
2. Rozbaľ ZIP a nahraj celý obsah projektu do repository tak, aby `settings.gradle.kts` bol v koreňovom priečinku.
3. Na GitHube otvor kartu **Actions** a povoľ Actions, ak sa zobrazí výzva.
4. Vyber workflow **Build KnotRow APK** a stlač **Run workflow** (alebo sa spustí po nahratí súborov).
5. Po dokončení otvor daný beh workflow, nájdi **Artifacts** a stiahni `KnotRow-debug-apk`.
6. Rozbaľ stiahnutý ZIP a otvor `app-debug.apk`. Android môže požiadať o povolenie inštalácie z daného zdroja.

Poznámka: GitHub účet je potrebný. APK je testovacia/debug verzia, nie publikovaná aplikácia v Google Play.
