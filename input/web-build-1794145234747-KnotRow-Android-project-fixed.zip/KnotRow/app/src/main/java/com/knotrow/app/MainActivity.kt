package com.knotrow.app

import androidx.activity.ComponentActivity
import android.os.Bundle
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import java.io.File
import java.io.FileOutputStream
import kotlin.math.max
import kotlin.math.min

class MainActivity : ComponentActivity() {
    private var source: Bitmap? = null
    private var row = 0
    private var rowCount = 20
    private var topPct = 0
    private var bottomPct = 100
    private var bandPct = 100
    private lateinit var image: ImageView
    private lateinit var status: TextView
    private lateinit var topLabel: TextView
    private lateinit var bottomLabel: TextView
    private lateinit var bandLabel: TextView
    private lateinit var rowsInput: EditText
    private lateinit var controls: LinearLayout

    private val picker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri ->
        if (uri != null) {
            try {
                contentResolver.openInputStream(uri)?.use { input ->
                    val bmp = BitmapFactory.decodeStream(input)
                    if (bmp != null) {
                        source = bmp
                        row = 0
                        persistImage(bmp)
                        render()
                    } else toast("Obrázok sa nepodarilo načítať.")
                }
            } catch (_: Exception) { toast("Obrázok sa nepodarilo načítať.") }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadSaved()
        buildUi()
        render()
    }

    private fun buildUi() {
        val outer = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(12), dp(16), dp(12))
            setBackgroundColor(Color.rgb(248, 246, 241))
        }
        val title = TextView(this).apply {
            text = "KnotRow"
            textSize = 27f; setTextColor(Color.rgb(35, 35, 42)); gravity = Gravity.CENTER
        }
        outer.addView(title, matchWrap())
        val subtitle = TextView(this).apply {
            text = "Celý riadok. Potom ďalší."
            textSize = 14f; gravity = Gravity.CENTER
            setTextColor(Color.DKGRAY)
        }
        outer.addView(subtitle, matchWrap())
        val import = Button(this).apply {
            text = "Importovať screenshot vzoru"
            setOnClickListener { picker.launch("image/*") }
        }
        outer.addView(import, matchWrap())
        status = TextView(this).apply {
            textSize = 18f; gravity = Gravity.CENTER; setPadding(0, dp(8), 0, dp(8))
            setTextColor(Color.rgb(35, 35, 42))
        }
        outer.addView(status, matchWrap())
        val imageScroll = ScrollView(this)
        image = ImageView(this).apply {
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
            setBackgroundColor(Color.WHITE)
        }
        imageScroll.addView(image, FrameLayout.LayoutParams(-1, -2))
        outer.addView(imageScroll, LinearLayout.LayoutParams(-1, 0, 1f))
        val nav = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
        nav.addView(Button(this).apply {
            text = "← Predošlý"
            setOnClickListener { if (row > 0) { row--; render() } }
        }, LinearLayout.LayoutParams(0, dp(52), 1f))
        nav.addView(Button(this).apply {
            text = "Ďalší →"
            setOnClickListener { if (row < rowCount - 1) { row++; render() } }
        }, LinearLayout.LayoutParams(0, dp(52), 1f))
        outer.addView(nav, matchWrap())
        val settingsButton = Button(this).apply {
            text = "Nastaviť výrez a počet riadkov"
            setOnClickListener { controls.visibility = if (controls.visibility == View.VISIBLE) View.GONE else View.VISIBLE }
        }
        outer.addView(settingsButton, matchWrap())
        controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
            setPadding(0, dp(4), 0, dp(4))
        }
        rowsInput = EditText(this).apply {
            hint = "Počet riadkov (napr. 20)"
            inputType = android.text.InputType.TYPE_CLASS_NUMBER
            setText(rowCount.toString())
        }
        controls.addView(rowsInput, matchWrap())
        topLabel = TextView(this); bottomLabel = TextView(this); bandLabel = TextView(this)
        addSlider(controls, "Začiatok vzoru", topLabel, topPct) { topPct = it; render() }
        addSlider(controls, "Koniec vzoru", bottomLabel, bottomPct) { bottomPct = it; render() }
        addSlider(controls, "Výška zobrazeného riadka", bandLabel, bandPct) { bandPct = max(30, it); render() }
        controls.addView(Button(this).apply {
            text = "Použiť nastavenia"
            setOnClickListener {
                val n = rowsInput.text.toString().toIntOrNull()
                if (n == null || n !in 1..300) toast("Zadaj počet riadkov od 1 do 300.")
                else { rowCount = n; row = min(row, rowCount - 1); saveSettings(); render(); controls.visibility = View.GONE }
            }
        }, matchWrap())
        outer.addView(controls, matchWrap())
        setContentView(outer)
    }

    private fun addSlider(parent: LinearLayout, label: String, valueView: TextView, initial: Int, changed: (Int) -> Unit) {
        valueView.text = "$label: $initial%"
        valueView.textSize = 13f
        parent.addView(valueView, matchWrap())
        parent.addView(SeekBar(this).apply {
            max = 1000
            progress = initial * 10
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, user: Boolean) {
                    if (user) { val v = p / 10; valueView.text = "$label: $v%"; changed(v) }
                }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) { saveSettings() }
            })
        }, matchWrap())
    }

    private fun render() {
        val bmp = source
        if (bmp == null) {
            status.text = "Importuj screenshot BraceletBook"
            image.setImageDrawable(null)
            return
        }
        val safeTop = topPct.coerceIn(0, 95)
        val safeBottom = bottomPct.coerceIn(safeTop + 1, 100)
        val yStart = (bmp.height * safeTop / 100f).toInt().coerceIn(0, bmp.height - 1)
        val yEnd = (bmp.height * safeBottom / 100f).toInt().coerceIn(yStart + 1, bmp.height)
        val regionHeight = yEnd - yStart
        val step = regionHeight.toFloat() / rowCount
        val center = yStart + step * (row + 0.5f)
        val desiredHeight = max(1, (step * bandPct.coerceIn(30, 150) / 100f).toInt())
        val cropTop = (center - desiredHeight / 2).toInt().coerceIn(0, bmp.height - 1)
        val cropBottom = (cropTop + desiredHeight).coerceAtMost(bmp.height)
        val cropped = Bitmap.createBitmap(bmp, 0, cropTop, bmp.width, max(1, cropBottom - cropTop))
        image.setImageBitmap(cropped)
        status.text = "Riadok ${row + 1} z $rowCount"
        saveSettings()
    }

    private fun persistImage(bitmap: Bitmap) {
        try {
            FileOutputStream(File(filesDir, "pattern.jpg")).use { bitmap.compress(Bitmap.CompressFormat.JPEG, 95, it) }
        } catch (_: Exception) {}
    }

    private fun loadSaved() {
        val p = getSharedPreferences("knotrow", MODE_PRIVATE)
        topPct = p.getInt("top", 0); bottomPct = p.getInt("bottom", 100)
        bandPct = p.getInt("band", 100); rowCount = p.getInt("rows", 20); row = p.getInt("row", 0)
        val f = File(filesDir, "pattern.jpg")
        if (f.exists()) source = BitmapFactory.decodeFile(f.absolutePath)
    }

    private fun saveSettings() {
        getSharedPreferences("knotrow", MODE_PRIVATE).edit()
            .putInt("top", topPct).putInt("bottom", bottomPct).putInt("band", bandPct)
            .putInt("rows", rowCount).putInt("row", row).apply()
    }

    private fun matchWrap() = LinearLayout.LayoutParams(-1, -2)
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()
}
